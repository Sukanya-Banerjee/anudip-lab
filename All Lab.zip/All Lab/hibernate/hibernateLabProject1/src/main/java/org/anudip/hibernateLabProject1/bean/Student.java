package org.anudip.hibernateLabProject1.bean;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name = "Student")
public class Student 
{
    @Id
    @Column(name = "Roll_Number")
    private String rollNumber;

    @Column(name = "Student_Name")
    private String studentName;

    @Column(name = "Semester")
    private String semester;

    @OneToOne(fetch = FetchType.LAZY, targetEntity = Result.class, cascade = CascadeType.ALL)
    @JoinColumn(name = "Roll_Number")
    private Result studentResult;

    // Add a field for halfYearlyTotal
    @Column(name = "Half_Yearly_Total")
    private double halfYearlyTotal;

    public Student()
    {
        super();
    }

    // Update the constructor to accept halfYearlyTotal
    public Student(String rollNumber, String studentName, String semester, double halfYearlyTotal)
    {
        super();
        this.rollNumber = rollNumber;
        this.studentName = studentName;
        this.semester = semester;
        this.halfYearlyTotal = halfYearlyTotal;
    }
// Getter and Setter method applied
    public String getRollNumber() 
    {
        return rollNumber;
    }

    public void setRollNumber(String rollNumber)
    {
        this.rollNumber = rollNumber;
    }

    public String getStudentName() 
    {
        return studentName;
    }

    public void setStudentName(String studentName) 
    {
        this.studentName = studentName;
    }

    public String getSemester()
    {
        return semester;
    }

    public void setSemester(String semester)
    {
        this.semester = semester;
    }

    public Result getStudentResult() 
    {
        return studentResult;
    }

    public void setStudentResult(Result studentResult) 
    {
        this.studentResult = studentResult;
    }

    public double getHalfYearlyTotal() 
    {
        return halfYearlyTotal;
    }

    public void setHalfYearlyTotal(double halfYearlyTotal)
    {
        this.halfYearlyTotal = halfYearlyTotal;
    }

    //Override toString() method
    @Override
    public String toString() 
    {
        return String.format("%-5s %-20s %-5s %-2s", rollNumber, studentName, semester, studentResult);
    }
}




