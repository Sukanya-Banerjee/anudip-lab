package org.anudip.hibernateLabProject1.dao;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.anudip.hibernateLabProject1.dao.*;
import org.anudip.hibernateLabProject1.bean.*;

public class DatabaseHandler
{
		 private static final DatabaseHandler dbHandler2 = new DatabaseHandler();
		    private static SessionFactory sessionFactory;

		    private DatabaseHandler() 
		    {
		    	//try block stared
		        try 
		        {
		            // Load Hibernate properties from hibernate.properties
		            Properties properties = new Properties();
		            InputStream hibernatePropsStream = getClass().getClassLoader().getResourceAsStream("hibernate.properties");
		            //Condition Checking
		            if (hibernatePropsStream != null) 
		            {
		                properties.load(hibernatePropsStream);
		            } 
		            else 
		            {
		                throw new IOException("Unable to load hibernate.properties");
		            }

		            // Create a Hibernate configuration
		            Configuration config = new Configuration();
		            config.setProperties(properties);
		            config.addAnnotatedClass(Student.class);
		            // Mention the entity class
		            config.addAnnotatedClass(Result.class);
		            // Build the SessionFactory
		            sessionFactory = config.buildSessionFactory();
		        }
		        catch (IOException e)
		        {
		          
		            e.printStackTrace();
		            throw new RuntimeException("Error initializing Hibernate configuration.");
		        }
		    }

		    // Get the single instance of DatabaseHandler
		    public static DatabaseHandler getDatabaseHandler() 
		    {
		        return dbHandler2;
		    }

		    // Create a Hibernate session
		    public Session createSession() 
		    {
		        if (sessionFactory == null)
		        {
		            throw new RuntimeException("Session factory is not initialized.");
		        }
		        return sessionFactory.openSession();
		    }

		    // Close a Hibernate session
		    public void closeSession(Session session) 
		    {
		        if (session != null && session.isOpen()) 
		        {
		            session.close();
		        }
		    }

		    // Close the SessionFactory
		    public void closeSessionFactory() 
		    {
		        if (sessionFactory != null && !sessionFactory.isClosed()) 
		        {
		            sessionFactory.close();

	            }
		    }
}


