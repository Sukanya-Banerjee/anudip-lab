package org.anudip.hibernateLabProject1.bean;

public class StudentNotFoundException extends RuntimeException
{
	static final long serialVersionUID=1L;
	public StudentNotFoundException(String message) 
	{
	        super(message);
	  
	}
	
}

