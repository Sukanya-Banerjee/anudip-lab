package org.anudip.hibernateLabProject.bean;
import java.util.Comparator;
import javax.persistence.*;

@Entity
@Table(name = "Product")
public class Product implements Comparable<Product> 
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Product_Id")
    private Integer productId;

    @Column(name = "product_name")
    private String productName;

    @Column(name = "purchase_price")
    private Double purchasePrice;

    @Column(name = "sales_price")
    private Double salesPrice;

    @Column(name = "grade")
    private String grade;

    public Product() 
    {
    }
//Generate constructor using fields
    public Product(Integer productId,String productName, Double purchasePrice, Double salesPrice, String grade) 
    {
        this.productName = productName;
        this.purchasePrice = purchasePrice;
        this.salesPrice = salesPrice;
        this.grade = grade;
    }
    //Getter and Setter method applied
	    public Integer getProductId() {
	        return productId;
	    }

	    public void setProductId(Integer productId) {
	        this.productId = productId;
	    }

	    public String getProductName() {
	        return productName;
	    }

	    public void setProductName(String productName) {
	        this.productName = productName;
	    }

	    public Double getPurchasePrice() {
	        return purchasePrice;
	    }

	    public void setPurchasedPrice(Double purchasePrice) {
	        this.purchasePrice = purchasePrice;
	    }

	    public Double getSalesPrice() {
	        return salesPrice;
	    }

	    public void setSalesPrice(Double salesPrice) {
	        this.salesPrice = salesPrice;
	    }

	    public String getGrade() {
	        return grade;
	    }

	    public void setGrade(String grade) {
	        this.grade = grade;
	    }
    //Override method apllied
	    @Override
	    public int compareTo(Product other) {
	        return Comparator.comparing(Product::getProductId)
	                .compare(this, other);
	    }
    //Generate to string() method
	    @Override
	    public String toString() {
	        return String.format("%-5s %-20s %-10s %-10s %-5s",
	                productId, productName, purchasePrice, salesPrice, grade);
	    }
}


