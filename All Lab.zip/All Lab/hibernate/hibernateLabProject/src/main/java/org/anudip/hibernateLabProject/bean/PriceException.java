package org.anudip.hibernateLabProject.bean;
	public class PriceException extends RuntimeException 
	{
	    public PriceException(String message) 
	    {
	        super(message);
	    }
	}

