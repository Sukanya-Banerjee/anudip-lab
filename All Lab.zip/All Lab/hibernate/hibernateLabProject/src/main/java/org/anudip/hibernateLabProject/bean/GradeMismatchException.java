package org.anudip.hibernateLabProject.bean;
	public class GradeMismatchException extends RuntimeException 
	{
	    public GradeMismatchException(String message) 
	    {
	        super(message);
	    }
	}
