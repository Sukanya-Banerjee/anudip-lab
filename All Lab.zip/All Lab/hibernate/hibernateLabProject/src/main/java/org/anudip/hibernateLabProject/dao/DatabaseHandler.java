package org.anudip.hibernateLabProject.dao;
import java.io.IOException;
import java.util.Properties;
import org.anudip.hibernateLabProject.bean.Product;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class DatabaseHandler
{
    private static final DatabaseHandler dbHandler = new DatabaseHandler();

    private DatabaseHandler()
    {
    	
    }

    public static DatabaseHandler getDatabaseHandler() 
    {
        return dbHandler;
    }

    public Session createSession() throws IOException 
    {
        
    	// Load Hibernate properties from hibernate.properties
        Properties properties = new Properties();
        properties.load(DatabaseHandler.class.getClassLoader().getResourceAsStream("hibernate.properties"));

        // Create a Hibernate configuration
        Configuration config = new Configuration();
        config.setProperties(properties);
        config.addAnnotatedClass(Product.class); 
        // Mention of entity class

        // Build the SessionFactory
        SessionFactory factory = config.buildSessionFactory();

        // Open a Hibernate session
        Session session = factory.openSession();
        return session;
    }

    public void closeSession(Session session) 
    {
        if (session != null) 
        {
            session.close();
        }
    }

    public void closeSessionFactory(SessionFactory factory) 
    {
        if (factory != null)
        {
            factory.close();
        }
    }
}



