package org.anudip.hibernateLabProject.application;
import java.util.List;
import org.anudip.hibernateLabProject.bean.Product;
import org.anudip.hibernateLabProject.dao.DatabaseHandler;
import org.hibernate.Session;
import org.hibernate.query.Query;

public class ProductShow 
{
	public static void main(String[] args) throws Exception
	{
		DatabaseHandler dbHandler=DatabaseHandler.getDatabaseHandler();
   	    Session session=dbHandler.createSession();
   	    String queryStatement="from Product";
     	Query<Product> query=session.createQuery(queryStatement);
        List<Product> ProductList=query.list();
        ProductList.forEach(product->System.out.println(product));
	   	session.close();
	}//end of main
}//end of class
	   
