package org.anudip.springBootLab.service;
import org.springframework.stereotype.Service;


@Service
public class CalculatorService 
{

    public int performCalculation(String operand1, String operand2, String operator) 
    // Convert the operand strings to integers
    {
        int num1 = Integer.parseInt(operand1);
        int num2 = Integer.parseInt(operand2);
        
        // Use a switch statement to determine the operation based on the operator
        switch (operator) 
        {
            case "+":
                return num1 + num2;
                //Addition
            case "-":
                return num1 - num2;
                //substraction
            case "*":
                return num1 * num2;
                //Multiplication
            case "/":
                if (num2 != 0) 
                {
                    return num1 / num2;
                    //Division
                } 
                else
                {
                    return -1; 
                    // Handle division by zero
                }
            default:
                return 0; 
                // Handle invalid operator
        }
    }
}
