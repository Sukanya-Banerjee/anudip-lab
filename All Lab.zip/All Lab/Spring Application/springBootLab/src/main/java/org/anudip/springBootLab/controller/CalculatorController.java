package org.anudip.springBootLab.controller;
import org.anudip.springBootLab.service.CalculatorService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller

public class CalculatorController 
{

	    private final CalculatorService calculatorService;
	 // Controller class for handling calculator-related requests
	   
	    public CalculatorController(CalculatorService calculatorService) 
	    {
	        this.calculatorService = calculatorService;
	    }

	    @RequestMapping("/calculator")
	    public String showCalculatorForm() 
	    {
	        return "calculatorEntry";
	    }

	    @PostMapping("/calculate")
	
	    public String calculate(String operand1, String operand2, String operator, Model model) 
	    {
	    	// Use the CalculatorService to perform the calculation
	    	int result = calculatorService.performCalculation(operand1, operand2, operator);
	        model.addAttribute("result", result);
	        // Add the result to the model, so it can be displayed in the view
	        return "calculatorResult";
	        // Return the name of the JSP view to display the result
	    }
	}//end of class calculator controller
