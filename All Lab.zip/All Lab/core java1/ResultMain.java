package org.anudip.lab2;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class ResultMain 
{
		private static StudentResult[] allStudents;
	    private static void convertToList() throws IOException 
	    {
	        List<StudentResult> studentList = new ArrayList<>();
	        BufferedReader reader = new BufferedReader(new FileReader("d:/StudentResult.txt"));
	        String line;
	        //condition checking
	        while ((line = reader.readLine()) != null)
	        {   
	        	//Split format using "-"
	            String[] data = line.split("-");
	            String rollNumber = data[0].trim();
	            String studentName = data[1].trim();
	            Double halfYearlyTotal = Double.parseDouble(data[2].trim());
	            studentList.add(new StudentResult(rollNumber, studentName, halfYearlyTotal));
	        }
	        allStudents = studentList.toArray(new StudentResult[0]);
	        reader.close();
	    }

	    public static void main(String[] args) 
	    {
	    	//try block starts
	        try 
	        {
	            //convertToList();
	            Scanner scanner = new Scanner(System.in);
	            System.out.print("Enter Roll Number: ");
	            String searchRoll = scanner.nextLine();

	            StudentResult studentToUpdate =null;
	            for (StudentResult student : allStudents)
	            {
	            	//Condition checking
	                if (student.getRollNumber().equals(searchRoll))
	                {
	                    studentToUpdate = student;
	                    break;
	                }
	            }
	            //condition checking
	            if (studentToUpdate == null) 
	            {
	                throw new StudentNotFoundException("Student with roll number " + searchRoll + " not found.");
	            }
	            else 
	            {
	                System.out.print("Enter marks for English: ");
	                double english = scanner.nextDouble();
	                System.out.print("Enter marks for Language: ");
	                double language = scanner.nextDouble();
	                System.out.print("Enter marks for Mathematics: ");
	                double mathematics = scanner.nextDouble();
	                System.out.print("Enter marks for Science: ");
	                double science = scanner.nextDouble();
	                System.out.print("Enter marks for Social Study: ");
	                double socialStudy = scanner.nextDouble();
	                
	                //calculate annual total of all subjects
	                double annualTotal = english + language + mathematics + science + socialStudy;
	                studentToUpdate.setAnnualTotal(annualTotal);
	                String grade = ResultService.gradeCalculation(studentToUpdate);
	                studentToUpdate.setGrade(grade);
	                
                    //FileWriter object points to file StudentResult.txt
	                FileWriter fileWriter = new FileWriter("d:/StudentResult.txt");
	                
	                //BufferedWriter will write inside the file which fileWriter is pointing to i.e StudentResult.txt
	                BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
	                for (StudentResult student : allStudents) 
	                {
	                    String str = student.toString();
	                    bufferedWriter.write(str);
	                    bufferedWriter.newLine();
	                }

	                bufferedWriter.close();
	                System.out.println("File Updated");
	            }
	        }//end of try block
	        
	        //catch block starts
	        catch (IOException e) 
	        {
	            e.printStackTrace();
	        } 
	        catch (StudentNotFoundException e)
	        {
	            System.out.println(e.getMessage());
	        }
	    }
}

