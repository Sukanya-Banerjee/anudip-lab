package org.anudip.lab2;
import java.util.Scanner;
public class FactorialNumberCheck
{
	    public static void main(String[] args) 
	    {   
	    	
	        Scanner scanner = new Scanner(System.in);
	        //Give user input
	        System.out.print("Enter a number: ");
	        int n = scanner.nextInt();
	        
	        //condition checking
	        if (isFactorialNumber(n))
	        {
	            System.out.println(n + " is a factorial number.");
	        }
	        else
{
	            System.out.println(n + " is not a factorial number.");
	        }
	    }

	    public static boolean isFactorialNumber(int n) 
	    {
	    	//condition checking
	        if (n <= 1) 
	        {
	            return false;
	        }
	        int x = 1;
	        int factorial = 1;
	        //condition checking
	        while (factorial < n) 
	        {
	            x++;
	            factorial *= x;
	        }
	        return factorial == n;
	    }
}
