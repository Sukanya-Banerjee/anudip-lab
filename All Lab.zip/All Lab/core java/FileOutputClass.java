package org.anudip.lab;
import java.io.BufferedWriter;//importing BufferedWriter package
import java.io.FileWriter;//importing FileWriter package
import java.io.IOException;//importing IOException package
import java.util.Scanner;
public class FileOutputClass {
	
	//Declaring the FileOutput Class
	
		public static void main(String[] args) throws IOException {
			Scanner scanner=new Scanner(System.in);
			// Using the FileWriter object to point to file StudentResult.txt in append mode
			FileWriter fileWriter=new FileWriter("d:/StudentResult.txt",true);
			//BufferedWriter will write inside the file which fileWriter is pointing to i.e StudentResult.txt
			BufferedWriter bufferedWriter=new BufferedWriter(fileWriter);
			//accepting the data from user
			System.out.println("Hi User, Please Enter a Text:");
			String str=scanner.nextLine();
			//BufferedWriter transfer the content to the File
			bufferedWriter.write(str);
			bufferedWriter.flush();
			bufferedWriter.newLine();
			bufferedWriter.close();
			fileWriter.close();
			scanner.close();
			System.out.println("Successfully File written");	
		}//end of public static void main
	}//end of FileOutput Class

