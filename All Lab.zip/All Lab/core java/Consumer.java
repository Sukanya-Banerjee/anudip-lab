package org.anudip.lab;

public class Consumer 
{
	    private String id;
	    private String name;
	    private Integer unitConsumed;
	    private String finalPayment;

	    // Constructors
	    public Consumer(String id, String name, Integer unitConsumed)
	    {
	        this.id = id;
	        this.name = name;
	        this.unitConsumed = unitConsumed;
	    }

	    // Getters and Setters method
	    public String getId()
	    {
	        return id;
	    }

	    public void setId(String id)
	    {
	        this.id = id;
	    }

	    public String getName() 
	    {
	        return name;
	    }

	    public void setName(String name)
	    {
	        this.name = name;
	    }

	    public Integer getUnitConsumed()
	    {
	        return unitConsumed;
	    }

	    public void setUnitConsumed(Integer unitConsumed) 
	    {
	        this.unitConsumed = unitConsumed;
	    }

	    public String getFinalPayment()
	    {
	        return finalPayment;
	    }

	    public void setFinalPayment(String finalPayment) 
	    {
	        this.finalPayment = finalPayment;
	    }

	    // Override toString() method
	    @Override
	    public String toString() 
	    {
	        return String.format("%-5s %-20s %-10s %-10s", id, name, unitConsumed, finalPayment);
	    }
}