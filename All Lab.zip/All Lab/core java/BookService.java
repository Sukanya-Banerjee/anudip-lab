package org.anudip.lab2;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class BookService {
	//Arrange books with their numbers from the ArrayList
	    public List<Book> arrangeBooksNumberWise(List<Book> bookList) {
	        List<Book> sortedList = new ArrayList<>(bookList);
	        sortedList.sort(Comparator.comparing(Book::getBookNumber));
	        return sortedList;
	    }
    //Arrange books with their book name wise from the ArrayList
	    public List<Book> arrangeBooksTitleWise(List<Book> bookList) {
	        List<Book> sortedList = new ArrayList<>(bookList);
	        sortedList.sort(Comparator.comparing(Book::getBookTitle));
	        return sortedList;
	    }
     //Arrange books with their book author wise from the ArrayList
	    public List<Book> arrangeBooksAuthorWise(List<Book> bookList) {
	        List<Book> sortedList = new ArrayList<>(bookList);
	        sortedList.sort(Comparator.comparing(Book::getAuthor));
	        return sortedList;
	    }
}


