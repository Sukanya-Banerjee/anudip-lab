package org.anudip.lab2;
import java.util.List;
import java.util.Scanner;
public class BookMain {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        BookService bookService = new BookService();
	        List<Book> books = Library.getAllBooks();
         //Condition checking
	        while (true) {
	            System.out.println("\nMenu");
	            System.out.println("1. Display Book Number-wise");
	            System.out.println("2. Display Book Title-wise");
	            System.out.println("3. Display Book Author-wise");
	            System.out.println("4. Exit");
	            System.out.print("Enter choice (1-4): ");
	            int choice = scanner.nextInt();
         // Enter the choice 
	            List<Book> sortedBooks = null;
         //Condition checking
	            switch (choice) {
	                case 1:
	                    sortedBooks = bookService.arrangeBooksNumberWise(books);
	                    break;
	                case 2:
	                    sortedBooks = bookService.arrangeBooksTitleWise(books);
	                    break;
	                case 3:
	                    sortedBooks = bookService.arrangeBooksAuthorWise(books);
	                    break;
	                case 4:
	                    System.out.println("Exiting...");
	                    scanner.close();
	                    System.exit(0);
	                default:
	                    System.out.println("Invalid choice. Please choose 1-4.");
	                    continue;
	            }
               //Output of their choice
	            System.out.println("\nBook Number         Book Title             Author");
	           //Condition checking
	            for (Book book : sortedBooks) {
	                System.out.println(book);
	            }
	        }
	    }
}

