package org.anudip.lab;
import java.io.*;//Importing the IO Package for enabling input, output operations
import java.util.Scanner;//Importing the Scanner Package for enabling data collection from User
//Declaring the ResultMain Class

public class ResultMain {
	
		// Declaring private class variables
	    private static StudentResult[] allStudents;// An array to store student results
	    private static final String FILE_PATH = "d:/StudentResult.txt";// Path to the data file
	    
	    // Method to get the number of students from the data file
	    private static int getNumberOfStudents() throws IOException {
	        BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH));
	        int numberOfStudents = 0;
	        
	        // Using While Looping to Count the number of lines in the file 
	        while (reader.readLine() != null) {
	            numberOfStudents++;
	        }//end of while

	        reader.close();
	        return numberOfStudents;
	    }//end of getNumberOfStudents
	    // Method to convert student data from the file to an array
	    private static void convertToList(int numberOfStudents) throws IOException {
	        allStudents = new StudentResult[numberOfStudents];
	        BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH));

	        String line;
	        int index = 0;
	        // Using the While Looping to Read each line from the file and splitting it to create StudentResult objects
	        while ((line = reader.readLine()) != null) {
	            String[] parts = line.split("-");
	            if (parts.length == 5) {
	                allStudents[index] = new StudentResult(parts[0], parts[1], Double.parseDouble(parts[2]));
	                index++;
	            }//end of if
	        }//end of while

	        reader.close();
	    }//end of convertToList
	    // Main method to run the program
	    public static void main(String[] args) {
	        try {
	        	// Getting the number of students and converting data to an array
	            int numberOfStudents = getNumberOfStudents();
	            convertToList(numberOfStudents);

	            Scanner scanner = new Scanner(System.in);

	            boolean continueEnteringMarks = true;
	            while (continueEnteringMarks) {
	                System.out.print("Hello User! Please Enter the Roll Number you want to Edit: Or enter 'Exit' to stop): ");
	                String input = scanner.nextLine();
	                //Using If looping to check if user enters exit then goes out of the whole system
	                if (input.equalsIgnoreCase("exit")) {
	                    continueEnteringMarks = false;
	                } else {
	                    StudentResult selectedStudent =null;
	                    boolean found = false;
	                    for (StudentResult student : allStudents) {
	                        if (student.getRollNumber().equals(input)) {
	                            selectedStudent = student;
	                            found = true;
	                            break;
	                        }//end of if1
	                    }//end of if2
	                    
	                    if (!found) {
	                        System.out.println("Oh no! Student with Roll Number " + input + " does'nt exist in our Database.");
	                    } else {
	                    	//Taking user inputs for Marks in the subjects for Annual
	                        System.out.print("Enter Marks for English: ");
	                        double englishMarks = scanner.nextDouble();
	                        System.out.print("Enter Marks for Language: ");
	                        double languageMarks = scanner.nextDouble();
	                        System.out.print("Enter Marks for Mathematics: ");
	                        double mathMarks = scanner.nextDouble();
	                        System.out.print("Enter Marks for Science: ");
	                        double scienceMarks = scanner.nextDouble();
	                        System.out.print("Enter Marks for Social Study: ");
	                        double socialStudyMarks = scanner.nextDouble();

	                        double annualTotal = englishMarks + languageMarks + mathMarks + scienceMarks + socialStudyMarks;
	                        selectedStudent.setAnnualTotal(annualTotal);
	                        selectedStudent.setGrade(ResultService.gradeCalculation(selectedStudent));

	                        updateFile(); // Call the method to update the file

	                        System.out.println("Congrats! Student Record is successfully Updated:\n" + selectedStudent);
	                    }//end of else1

	                    scanner.nextLine();
	                }//end of else2
	            }//end of while

	            System.out.println("Exiting Program.");
	        } catch (IOException e) {
	            System.err.println("Error Reading or Writing to file: " + e.getMessage());
	        } catch (StudentNotFoundException e) {
	            System.err.println("Error: " + e.getMessage());
	        }//end of catch block
	    }//end of void main
	    // Method to update the data file with the new student information
	    private static void updateFile() throws IOException {
	        PrintWriter writer = new PrintWriter(new FileWriter(FILE_PATH));
	        for (StudentResult student : allStudents) {//start of for loop
	            writer.println(student.getRollNumber() + "-" +
	                    student.getStudentName() + "-" +
	                    student.getHalfYearlyTotal() + "-" +
	                    //Formating to show output only upto 2 decimal points
	                    String.format("%.2f", student.getAnnualTotal()) + "-" +
	                    student.getGrade());
	        }//end of for loop
	        writer.close();
	    }//end of updateFile
	}//end of result mail
