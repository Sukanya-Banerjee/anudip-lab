package org.anudip.lab;
import java.util.Scanner;
public class MailCreater {
	public static String CreateMailAccount(String StudentName)
	{
		String mailId=StudentName.replace(' ','.');
		//Remove Spaces
		return mailId;
		//return mail id
	}
	
	public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	//Accept the string
	System.out.println("Enter a Student Name: ");
	String StudentName=scanner.nextLine();
	String mail="@tsr.edu";
	String a=StudentName.toLowerCase();
	//Convert String to Lower case
	String[]arr=a.split(" ");
	StudentName.replace(' ','.');
	String emailId=CreateMailAccount(StudentName);
	//Check if length of the name is equals to 3 or not
	if(arr.length==3)
	{
		System.out.println("Email Id of the Student: ");
		System.out.println(arr[0]+'.'+arr[1]+'.'+arr[2]+mail);
		//Display the output

	}
	else 
	{
	System.out.println("Email Id of the Student: ");
	System.out.println(arr[0]+'.'+arr[1]+mail);
	//Display the output

	}
	}
}

