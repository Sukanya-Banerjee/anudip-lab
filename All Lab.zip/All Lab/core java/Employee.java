package org.anudip.lab2;
public class Employee implements Comparable<Employee> 
{
	    private String employeeId;
	    private String employeeName;
	    private String department;
     //Generate constructor using field
	    public Employee(String employeeId, String employeeName, String department) 
	    {
	        this.employeeId = employeeId;
	        this.employeeName = employeeName;
	        this.department = department;
	    }
     //Getter and Setter method applied
	    public String getEmployeeId() 
	    {
	        return employeeId;
	    }

	    public void setEmployeeId(String employeeId) 
	    {
	        this.employeeId = employeeId;
	    }

	    public String getEmployeeName() 
	    {
	        return employeeName;
	    }

	    public void setEmployeeName(String employeeName)
	    {
	        this.employeeName = employeeName;
	    }

	    public String getDepartment() 
	    {
	        return department;
	    }

	    public void setDepartment(String department) 
	    {
	        this.department = department;
	    }

	    public void calculateTax() 
	    {
	        // To be implemented in subclasses
	    }
     
	    //Override method applied
	    @Override
	    public String toString()
	    {
	        return String.format("%-10s %-20s %-15s", employeeId, employeeName, department);
	    }
       //override method applied
	    @Override
	    public int compareTo(Employee other) 
	    {
	        return this.employeeId.compareTo(other.employeeId);
	    }
}

