package org.anudip.lab;
import java.util.Scanner;
public class FibonacciSequenceChecking {
	     static boolean isPerfectSquare(int n)
		    {
		        int sq = (int) Math.sqrt(n);
		        return sq * sq == n;
		    }
		 public static boolean isFibonacci(int n)
		    {
		        return isPerfectSquare(5 * n * n + 4) || isPerfectSquare(5 * n * n - 4);
		    }
		 public static void main(String[]args)
		    {
		        Scanner scanner = new Scanner(System.in);
		        // Accept the input number
		        
		        System.out.print("Enter the number: ");
		        int number = scanner.nextInt();
		        // Check if the number is part of the Fibonacci sequence
		        
		        boolean isFibonacci = isFibonacci(number);
		        // Display the result
		        
		        if (isFibonacci)
		        {
		            System.out.println("Yes");
		        }
		        else
		        {
		            System.out.println("No");
		        }
		    }

	}
