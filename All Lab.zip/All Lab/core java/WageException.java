package org.anudip.lab;

public class WageException extends Exception {
	    static final long serialVersionUID=1L;
	    public WageException(String message) {
	        super(message);
	    }
}
