package org.anudip.lab;
import java.util.Scanner;
public class ApplicantMain
{
	
	    public static void main(String[] args) 
	    {
	        Scanner scanner = new Scanner(System.in);
	        System.out.print("Enter the number of applicants: ");
	        int numApplicants = scanner.nextInt();
	        scanner.nextLine();
	        // Consume the newline left by nextInt()

	        Applicant[] applicants = new Applicant[numApplicants];

	        for (int i = 0; i < numApplicants; i++) 
	        {
	            System.out.print("Enter applicant details "+(i+1)+"(Name, Subject1, Subject2, Subject3): ");
	            String input = scanner.nextLine();
	            String[] details = input.split(",");

	            // Extract applicant details from input
	            String name = details[0];
	            int subject1 = Integer.parseInt(details[1]);
	            int subject2 = Integer.parseInt(details[2]);
	            int subject3 = Integer.parseInt(details[3]);

	            // Check for valid marks range (0-100)
	            if (subject1 < 0 || subject1 > 100 || subject2 < 0 || subject2 > 100 || subject3 < 0 || subject3 > 100) 
	            {
	                System.out.println("Error: Marks should be between 0 and 100.");
	                i--; // Repeat this iteration for valid input
	                continue;
	            }

	            // Create Applicant object and store in the array
	            applicants[i] = new Applicant(name, subject1, subject2, subject3);
	        }

	        scanner.close();

	        // Display passed applicants' details
	        System.out.println("\nPassed Applicants Details:");
	        System.out.println(String.format("%-10s %-5s %-5s %-5s %-10s %-10s", "Name", "Sub1", "Sub2", "Sub3", "Total", "Percentage"));
	        for (Applicant applicant : applicants) 
	        {
	            int total = totalCalculation(applicant);
	            int percentage = percentageCalculation(total);
	            applicant.setTotal(total);
	            applicant.setPercentage(percentage);
	            if (percentage >= 70) 
	            {
	                System.out.println(applicant);
	            }
	        }
	    }

	    public static int totalCalculation(Applicant applicant) 
	    {
	        // If any subject's mark is below 50, return 0 as they haven't qualified
	        if (applicant.getSubject1() < 50 || applicant.getSubject2() < 50 || applicant.getSubject3() < 50) {
	            return 0;
	        }
	        return applicant.getSubject1() + applicant.getSubject2() + applicant.getSubject3();
	    }

	    public static int percentageCalculation(int total) 
	    {
	        return (total * 100) / 300;
	    }
}

	