package org.anudip.lab2;

public class PermanentEmployee extends Employee 
{
	    private Double monthlySalary;
	    private Double pf;
	    private Double tax;
	    private static int idGen = 1000;

	    public PermanentEmployee(String employeeName, String department, Double monthlySalary)
	    {
	        super(generateId(), employeeName, department);
	        this.monthlySalary = monthlySalary;
	        this.pf = 0.15 * monthlySalary;
	    }
    //Getter and setter method applied
	    public Double getMonthlySalary() 
	    {
	        return monthlySalary;
	    }

	    public void setMonthlySalary(Double monthlySalary) 
	    {
	        this.monthlySalary = monthlySalary;
	        this.pf = 0.15 * monthlySalary;
	    }
     
	    //override method applied
	    @Override
	    public void calculateTax() 
	    {
	        this.tax = 0.1 * (12 * monthlySalary);
	    }
    
	    //override method applied
	    @Override
	    public String toString()
	    {
	        return String.format("%-15s %-15s %-15s %-15s %-15s %-15s", getEmployeeId(), getEmployeeName(), getDepartment(), monthlySalary, pf,tax);
	    }
       //ID generator 
	    private static String generateId() 
	    {
	        return "P" + ++idGen;
	    }
}

