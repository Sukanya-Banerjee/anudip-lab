package org.anudip.lab;
import java.text.DecimalFormat;
import java.util.Scanner;
public class EmployeeWage 
{
	    private static final int MIN_WORKERS = 5;
	    private static final double MIN_WAGE = 100.00;
	    private static final double MAX_WAGE = 250.00;

	    public static String convertToTwoDecimalPlace(double value)
	    //Converting two decimal places
	    {
	        DecimalFormat df = new DecimalFormat("#.00");
	        return df.format(value);
	    }

	    public static void main(String[] args) 
	    {
	        Scanner scanner = new Scanner(System.in);
	        //Input from user
	        System.out.print("Enter the number of workers at the site: ");
	        int numWorkers = scanner.nextInt();

	        if (numWorkers < MIN_WORKERS) 
	        	//Condition Checking
	        {
	            System.out.println("Wrong workers number. Minimum value should be 5.");
	            scanner.close();
	            return;
	        }

	        double totalWage = 0.0;
	        double[] wages = new double[numWorkers];

	        for (int i = 0; i < numWorkers; i++) 
	        {
	            System.out.print("Enter the daily wage for worker " + (i + 1) + ": ");
	            double wage = scanner.nextDouble();

	            while (wage < MIN_WAGE || wage > MAX_WAGE)
	            	//Checking conditions
	            {
	                System.out.println("WageException: Wage should be between 100.00 and 250.00.");
	                System.out.print("Re-enter the daily wage for worker " + (i + 1) + ": ");
	                wage = scanner.nextDouble();
	            }

	            wages[i] = wage;
	            totalWage += wage;
	            //Calculate total wage
	        }

	        double averageWage = totalWage / numWorkers;

	        System.out.println("Total wage expense for the site: " + convertToTwoDecimalPlace(totalWage));
	       //output Total wage 
	        System.out.println("Average wage for the site: " + convertToTwoDecimalPlace(averageWage));
          //Output Average Wage
	        scanner.close();
	    }
	}
