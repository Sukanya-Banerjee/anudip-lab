package org.anudip.lab2;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class EmployeeMain 
{
	    public static void main(String[] args)
	    {
	        Scanner scanner = new Scanner(System.in);
	        //create list of permanent employee and contract employee
	        List<Employee> permanentEmployees = new ArrayList<>();
	        List<Employee> contractEmployees = new ArrayList<>();
            //User input
	        System.out.print("Enter the number of employees: ");
	        int numEmployees = scanner.nextInt();
	        scanner.nextLine(); 
	        // Consume the newline
            
	        //Condition checking
	        for (int i = 0; i < numEmployees; i++) 
	        {
	            System.out.print("Enter employee details (name, department, salary/contract period, amount): ");
	            //user input splitting by ","
	            String[] details = scanner.nextLine().split(",");
                //Condition checking
	            if (details.length == 3) 
	            {
	                String name = details[0].trim();
	                String department = details[1].trim();
	                double salary = Double.parseDouble(details[2].trim());
	                PermanentEmployee permanentEmployee = new PermanentEmployee(name, department, salary);
	                permanentEmployee.calculateTax();
	                permanentEmployees.add(permanentEmployee);
	            }
	            else if (details.length == 4) 
	            {
	                String name = details[0].trim();
	                String department = details[1].trim();
	                int contractPeriod = Integer.parseInt(details[2].trim());
	                double contractAmount = Double.parseDouble(details[3].trim());
	                ContractEmployee contractEmployee = new ContractEmployee(name, department, contractPeriod, contractAmount);
	                contractEmployee.calculateTax();
	                contractEmployees.add(contractEmployee);
	            }
	        }
          //sorting of Permanent Employee
	        Collections.sort(permanentEmployees);
	      //sorting of contract Employee in reverse order
	        Collections.sort(contractEmployees, Collections.reverseOrder());
          //Output for permanent Employee
	        System.out.println("\nPermanent Employees:");
	        System.out.println("ID         Name                 Department      Salary          PF              Tax");
	        for (Employee employee : permanentEmployees) 
	        {
	            System.out.println(employee);
	        }
          //Output of Contract Employee
	        System.out.println("\nContract Employees:");
	        System.out.println("ID         Name                 Department      Period          Amount          Tax");
	        for (Employee employee : contractEmployees)
	        {
	            System.out.println(employee);
	        }
	    }
}
	    	


