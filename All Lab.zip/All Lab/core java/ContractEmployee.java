package org.anudip.lab2;

public class ContractEmployee extends Employee
{
	    private Integer contractPeriod;
	    private Double contractAmount;
	    private Double tax;
	    private static int idGenerator = 2000;
      //constructor using fields
	    public ContractEmployee(String employeeName, String department, Integer contractPeriod, Double contractAmount) 
	    {
	        super(generateId(), employeeName, department);
	        this.contractPeriod = contractPeriod;
	        this.contractAmount = contractAmount;
	        calculateTax();
	    }

	    // override method applied

	    @Override
	    public void calculateTax() 
	    {
	        this.tax = 0.1 * (contractAmount/contractPeriod);
	    }
      //override method applied
	    @Override
	    public String toString() 
	    {
	        return String.format("%-15s %-15s %-15s %-15s %-15s %-15s", getEmployeeId(), getEmployeeName(),getDepartment(),contractPeriod,contractAmount,tax);
	    }

	    private static String generateId() 
	    {
	        idGenerator++;
	        return "C" + idGenerator;
	    }
}


