package org.anudip.lab2;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class UserApplication 
{
	private static List<User> userList = new ArrayList<>();
    public static void uploadToList() 
    {
    	//Starting of try block
        try (BufferedReader reader = new BufferedReader(new FileReader("d:/UserMaster.txt"))) 
        //BufferedReader will read from the file which fileReader is pointing to i.e UserMaster.txt
        {
            String line;
            //Condition Checking
            while ((line = reader.readLine()) != null) 
            {
            	//Splitting by ","
                String[] parts = line.split(",");
                //Condition Checking
                if (parts.length == 2)
                {
                    String userId = parts[0].trim();
                    String password = parts[1].trim();
                    userList.add(new User(userId, password));
                }
            }
        }
        //Catch block
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
    public static void main(String[] args) 
    {
    	//Main Function Starts
        uploadToList();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter User Id:");
        String enteredUserId = scanner.nextLine().trim();
        System.out.println("Enter Password:");
        String enteredPassword = scanner.nextLine().trim();
        boolean isValidUser = false;
        //Condition Checking
        for (User user : userList) 
        {
            if (user.getUserId().equals(enteredUserId) && user.getPassword().equals(enteredPassword))
            {
                isValidUser = true;
                break;
            }
        }
        //condition checking
        if (isValidUser)
        {
        	System.out.println("Valid User");
        }
        else 
        {
            System.out.println("Invalid User");
        }
        scanner.close();
    }
}

	
  


