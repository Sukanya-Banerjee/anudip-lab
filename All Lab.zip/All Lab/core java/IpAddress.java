package org.anudip.lab;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class IpAddress {

	public static void main(String[] args) 
	{
				Scanner scanner=new Scanner(System.in);
				//Accept the Input
				System.out.println("Enter an Ip address:");
				//Using String Input
				String ip=scanner.nextLine();
				//Using regex for program
				String regex = "((25[0-5]|(2[0-4]|1\\d|[1-9]|)\\d)\\.?\\b){4}$";
				//Input Pattern
				Pattern pattern = Pattern.compile(regex);
				Matcher matcher = pattern.matcher(ip);
				matcher.matches();
				//Checking The Ip Address valid or not 
				if (matcher.matches()) 
				{
					System.out.println("valid IP Address");
					//output of the program
			    }
				else 
				{
					System.out.println("Invalid IP Adress");
					//output of the program
				                
				}
		}//end of main
}//end of class