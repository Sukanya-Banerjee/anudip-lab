package org.anudip.lab;
import java.util.Scanner;
public class BillMain 
{
	    public static void main(String[] args) 
	    {
	        Scanner scanner = new Scanner(System.in);

	        System.out.print("Enter the number of consumers: ");
	        int numConsumers = scanner.nextInt();
           //checking if number of consumer is less than zero or not
	        if (numConsumers <= 0)
	        {
	            System.out.println("Invalid input");
	            scanner.close();
	            return;
	        }

	        Consumer[] consumers = new Consumer[numConsumers];

	        for (int i = 0; i < numConsumers; i++) 
	        {   
	        	//Taking input from user
	            System.out.print("Enter details of consumer number " +" "+ (i + 1) + "(ID,Name,Unit Consumed ):");
	            String consumerDetails = scanner.next();
	            
	            //Details in split format
	            String[] details = consumerDetails.split(",");
               
	            //Condition checking
	            if (details.length != 3) 
	            {
	                System.out.println("Invalid input format. Please try again.");
	                i--;
	                continue;
	            }

	            String id = details[0];
	            String name = details[1];
	            int unitConsumed = Integer.parseInt(details[2]);

	            consumers[i] = new Consumer(id, name, unitConsumed);
	            String finalPayment = BillService.billCalculation(consumers[i]);
	            consumers[i].setFinalPayment(finalPayment);
	        }
            //output
	        System.out.println("\nConsumer Details:");
	        //headings
	        System.out.println("=================");
	        //main output in table format
	        System.out.println(String.format("%-5s %-20s %-10s %-10s", "ID", "Name", "Units", "Amount"));
	        //Output 
	        System.out.println("----------------------------------------------");
	        for (Consumer consumer : consumers)
	        {
	            System.out.println(consumer);
	        }

	        scanner.close();
	    }
}

