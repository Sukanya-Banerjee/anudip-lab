package org.anudip.lab;
import java.util.Scanner;
public class FibonacciSequenceCheck {

	public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	System.out.println("Enter a Number: ");
	int inputnumber=scanner.nextInt();
	int firstnumber=0;
	int secondnumber=1;
	int thirdnumber=0;
	int i=1;
	while(i<=inputnumber)
	{   
		System.out.println("  "+firstnumber);
		thirdnumber=firstnumber+secondnumber;
		firstnumber=secondnumber;
		secondnumber=thirdnumber;
		i++;
	}
	if(thirdnumber==inputnumber)
	{
		System.out.println("Number belongs to fibonacci Sequence");
	}
	else
	{
		System.out.println("Number is not belongs to fibonacci sequence");
	}
	}

}
