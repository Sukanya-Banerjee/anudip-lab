package org.anudip.lab;
import java.util.Arrays;
import java.util.Scanner;
public class AnagramCheck {
      public static boolean checkAnagram(String string1, String string2) 
		    {
		        // Remove spaces and convert strings to lowercase
		        String firstString1 = string1.replaceAll("\\s", "").toLowerCase();
		        String secondString2 = string2.replaceAll("\\s", "").toLowerCase();
		        // Check if the lengths are equal
		        
		        if (firstString1.length() != secondString2.length()) 
		        {
		            return false;
		        }
		        // Convert strings to character arrays and sort them
		        char[] charArray1 = firstString1.toCharArray();
		        char[] charArray2 = secondString2.toCharArray();
		        Arrays.sort(charArray1);
		        Arrays.sort(charArray2);
		        // Compare sorted character arrays
		        return Arrays.equals(charArray1, charArray2);
		    }
	 public static void main(String[] args) 
	 {
		        Scanner scanner = new Scanner(System.in);
		        // Accept the two strings
		        System.out.print("Enter the first string: ");
		        String string1 = scanner.nextLine();
		        System.out.print("Enter the second string: ");
		        String string2 = scanner.nextLine();
		        // Check if the strings are anagrams
		        boolean isAnagram = checkAnagram(string1, string2);
		        // Display the result
		        if (isAnagram) 
		        {
		            System.out.println("The strings are anagrams.");
		        } 
		        else 
		        {
		            System.out.println("The strings are not anagrams.");
		        }
		    }

	}
