package org.anudip.lab2;

public class Book 
{
	    private Integer bookNumber;
	    private String bookTitle;
	    private String author;

	    public Book(Integer bookNumber, String bookTitle, String author)
	    {
	        this.bookNumber = bookNumber;
	        this.bookTitle = bookTitle;
	        this.author = author;
	    }
       //Getter and Setter method applied
	    public Integer getBookNumber()
	    {
	        return bookNumber;
	    }

	    public String getBookTitle() 
	    {
	        return bookTitle;
	    }

	    public String getAuthor() 
	    {
	        return author;
	    }
       //Override method applied
	    @Override
	    public String toString() 
	    {
	        return String.format("%-10s %-35s %-20s", bookNumber, bookTitle, author);
	    }
}

