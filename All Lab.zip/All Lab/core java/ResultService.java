package org.anudip.lab;

public class ResultService {
	//Declaring the ResultService Class
	    public static String gradeCalculation(StudentResult result) {
	        double total = result.getHalfYearlyTotal() + result.getAnnualTotal();
	        //Percentage calculation
	        double percentage = (total / 1000) * 100;
	        //If looping for Grade marking
	        if (percentage >= 90) {
	            return "E";
	        } else if (percentage >= 75) {
	            return "V";
	        } else if (percentage >= 60) {
	            return "G";
	        } else if (percentage >= 45) {
	            return "P";
	        } else {
	            return "F";
	        }
	    }//end of gradeCalculation
	}//end of ResultService Class
