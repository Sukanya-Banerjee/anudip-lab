package org.anudip.SecondLabBoot.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PositiveOrZero;

@Entity
public class AccountHolder {
	

	    @Id
	    private Long accountNumber;
	    private String holderName;

	    @NotNull
	    @PositiveOrZero
	    private Double balanceAmount;

	    public AccountHolder() {
	        this.balanceAmount = 0.0; // Initialize balanceAmount to 0.0 by default
	    }

	    public AccountHolder(Long accountNumber, String holderName, Double balanceAmount) {
	        this.accountNumber = accountNumber;
	        this.holderName = holderName;
	        this.balanceAmount = balanceAmount;
	    }

	    public AccountHolder(Long accountNumber) {
	        this.accountNumber = accountNumber;
	        this.balanceAmount = 0.0; // Initialize balanceAmount to 0.0 by default
	    }

	    public Long getAccountNumber() {
	        return accountNumber;
	    }

	    public void setAccountNumber(Long accountNumber) {
	        this.accountNumber = accountNumber;
	    }

	    public String getHolderName() {
	        return holderName;
	    }

	    public void setHolderName(String holderName) {
	        this.holderName = holderName;
	    }

	    @PositiveOrZero
	    public Double getBalanceAmount() {
	        return balanceAmount;
	    }

	    public void setBalanceAmount(Double balanceAmount) {
	        this.balanceAmount = balanceAmount;
	    }

	    @Override
	    public String toString() {
	        return "accountNumber=" + accountNumber + ", holderName=" + holderName + ", balanceAmount=" + balanceAmount;
	    }

}
