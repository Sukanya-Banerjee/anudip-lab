package org.anudip.SecondLabBoot.exception;

public class AccountException extends RuntimeException {

	public AccountException(String string) {
		// TODO Auto-generated constructor stub
	}

}
