package org.anudip.SecondLabBoot.dao;

import java.util.List;

import org.anudip.SecondLabBoot.bean.AccountHolder;

public interface AccountHolderDao {
	public void saveAccount(AccountHolder accountHolder);//store new course
	public List<AccountHolder> displayAllAccounts();
	public AccountHolder findAAccountByNumber(Long accountNumber);
	public Long generateNewAccountNumber();
	public void deleteAccountByNumber(Long accountNumber);
	public List<AccountHolder> getAllAccountNumbers();
	//public List<AccountHolder> getAllAccountHolders();


}
