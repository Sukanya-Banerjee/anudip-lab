package org.anudip.SecondLabBoot.dao;

import java.util.List;

import org.anudip.SecondLabBoot.bean.AccountHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class AccountHolderDaoImpl implements AccountHolderDao {

    @Autowired
    private AccountRepository accountRepository; // Assuming you have a repository to interact with the database

    @Override
    public void saveAccount(AccountHolder accountHolder) {
        accountRepository.save(accountHolder);
    }

    @Override
    public List<AccountHolder> displayAllAccounts() {
        return accountRepository.findAll();
    }

    @Override
    public AccountHolder findAAccountByNumber(Long accountNumber) {
        return accountRepository.findById(accountNumber).orElse(null);
    }

    @Override
    public Long generateNewAccountNumber() {
        // You can implement logic to generate a new unique account number here
        // For example, querying the database for the maximum account number and adding 1
        // This example assumes you already have a way to generate unique account numbers
        // Replace this logic with your own if needed
        Long newAccountNumber = 1001L; // A default starting number
        return newAccountNumber;
    }

    @Override
    public void deleteAccountByNumber(Long accountNumber) {
        accountRepository.deleteById(accountNumber);
    }

    @Override
    public List<AccountHolder> getAllAccountNumbers() {
        return accountRepository.getAllaccountNumbers();
    }
}