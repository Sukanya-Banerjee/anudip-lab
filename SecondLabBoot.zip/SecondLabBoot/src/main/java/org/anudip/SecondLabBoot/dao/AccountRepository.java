
package org.anudip.SecondLabBoot.dao;

import java.util.List;

import org.anudip.SecondLabBoot.bean.AccountHolder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface AccountRepository extends JpaRepository<AccountHolder, Long> {
	@Query("select count(accountNumber) from AccountHolder")
	public int getAccountCount();
	
	@Query("select accountNumber from AccountHolder")
	public List<AccountHolder> getAllaccountNumbers();

}
