package org.anudip.SecondLabBoot.controller;

import org.anudip.SecondLabBoot.bean.AccountHolder;
import org.anudip.SecondLabBoot.dao.AccountHolderDao;
import org.anudip.SecondLabBoot.exception.AccountException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
@ControllerAdvice
public class AccountController {
	@Autowired
    private AccountHolderDao accountHolderDao;

    @GetMapping("/index")
    public ModelAndView showIndexPage() {
        return new ModelAndView("index");
    }

    @GetMapping("/accountEntry")
    public ModelAndView showAccountEntryPage() {
        ModelAndView mv = new ModelAndView("accountEntry");
        long newNumber = accountHolderDao.generateNewAccountNumber();
        AccountHolder accountHolder = new AccountHolder(newNumber);
        mv.addObject("accountHolder", accountHolder); // Corrected model attribute name
        return mv;
    }

    @PostMapping("/accountEntry")
    public ModelAndView  saveAccountAndDisplay(@ModelAttribute("accountHolder") AccountHolder accountHolder) {
        if (accountHolder.getBalanceAmount() < 10000.00) {
            throw new AccountException("Minimum balance criteria not met.");
        }
      accountHolderDao.saveAccount(accountHolder);
   ModelAndView mv = new ModelAndView("accountDisplay");
        mv.addObject("accountHolder", accountHolder);
        return mv;
    }

    @ExceptionHandler(AccountException.class)
    public ModelAndView handleAccountException(AccountException e) {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("accountEntry"); // Return to the account entry page
        modelAndView.addObject("error", e.getMessage()); // Add the error message to the model
        return modelAndView;
    }

}
